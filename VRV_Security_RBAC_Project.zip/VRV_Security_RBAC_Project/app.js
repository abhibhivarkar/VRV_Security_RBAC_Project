document.addEventListener('DOMContentLoaded', () => {
    console.log('RBAC Admin Dashboard Initialized');
    
    const app = document.getElementById('app');
    if (app) {
        app.innerHTML = `<p>Use the menu to manage users, roles, and permissions.</p>`;
    } else {
        console.error('Element with id "app" not found.');
    }
});
